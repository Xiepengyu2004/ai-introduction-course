"""基础实验 2：AdamW、学习率调度与梯度裁剪。"""

import math
from collections.abc import Callable, Iterable

from torch import Tensor, nn
from torch.optim import Optimizer


class AdamW(Optimizer):
    def __init__(
        self, params, lr: float = 1e-3, betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8, weight_decay: float = 0.01,
    ):
        # TODO 3：检查超参数合法，把它们放进 defaults 字典，调用 super().__init__(params, defaults)。
        raise NotImplementedError("TODO 3：完成 opt.py 中的 AdamW.__init__")

    def step(self, closure: Callable[[], Tensor] | None = None) -> Tensor | None:
        """执行一次参数更新；每个参数的优化器状态可保存和恢复。

        每个参数 p 的状态放在 self.state[p] 里：step（更新次数）、m、v（初值 0，形状同 p）。
        对每个有梯度 g 的参数，第 t 次更新（讲义 Algorithm 1）：
            m ← β1·m + (1 − β1)·g
            v ← β2·v + (1 − β2)·g²
            α_t = lr · sqrt(1 − β2^t) / (1 − β1^t)
            p ← p − α_t · m / (sqrt(v) + eps)
            p ← p − lr · weight_decay · p
        在 torch.no_grad() 下原地更新；p.grad 为 None 的参数跳过；lr 每次从 group 里读，
        因为学习率调度会修改它。
        """
        # TODO 3：完成 AdamW 更新。
        raise NotImplementedError("TODO 3：完成 opt.py 中的 AdamW.step")


def get_lr_cosine_schedule(
    it: int, max_learning_rate: float, min_learning_rate: float,
    warmup_iters: int, cosine_cycle_iters: int,
) -> float:
    """返回当前迭代的学习率；cosine_cycle_iters 是衰减结束的迭代数。

    阶段为线性预热、余弦衰减、保持最小学习率。记 Tw = warmup_iters，Tc = cosine_cycle_iters（讲义 §4.4）：
        it < Tw：        lr = it / Tw · max_lr
        Tw ≤ it ≤ Tc：   lr = min_lr + 0.5 · (1 + cos((it − Tw) / (Tc − Tw) · π)) · (max_lr − min_lr)
        it > Tc：        lr = min_lr
    """
    # TODO 4：按上面的公式完成学习率调度。
    raise NotImplementedError("TODO 4：完成 opt.py 中的 get_lr_cosine_schedule")


def gradient_clipping(parameters: Iterable[nn.Parameter], max_l2_norm: float) -> None:
    """对所有参与训练的梯度按整体 L2 范数原地裁剪。

    parameters 可以是一次性迭代器；允许参数的 grad 为 None。
    使用讲义规定的 epsilon=1e-6。

    所有梯度合在一起的 L2 范数 = sqrt(各梯度平方和之和)。超过 max_l2_norm 时，
    所有梯度乘同一个系数 max_l2_norm / (范数 + 1e-6)，否则不变（讲义 §4.5）。
    parameters 可能只能遍历一次，先转成 list；跳过 grad 为 None 的参数。
    """
    # TODO 5：按上面的步骤完成梯度裁剪。
    raise NotImplementedError("TODO 5：完成 opt.py 中的 gradient_clipping")
