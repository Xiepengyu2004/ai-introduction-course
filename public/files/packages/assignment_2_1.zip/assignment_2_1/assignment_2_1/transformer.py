"""基础实验 3：pre-norm Transformer Block 与完整语言模型。"""
from torch import nn, Tensor
from .layers import RMSNorm, SwiGLU
from .attention import CausalSelfAttention


class TransformerBlock(nn.Module):
    """输入与输出 (B, N, d_model)，无 dropout、无额外的最终归一化。

    positions 与 CausalSelfAttention 的约定相同。
    """

    def __init__(self, d_model: int, num_heads: int, d_ff: int,
                 max_seq_len: int = 128, theta: float = 10000.0):
        super().__init__()
        self.ln1 = RMSNorm(d_model)
        self.attn = CausalSelfAttention(d_model, num_heads, max_seq_len, theta)
        self.ln2 = RMSNorm(d_model)
        self.ffn = SwiGLU(d_model, d_ff)

    def forward(self, x: Tensor, positions: Tensor | None = None) -> Tensor:
        # TODO 6：按照讲义组装两个 pre-norm 子层及其残差连接。
        raise NotImplementedError("TODO 6：完成 transformer.py 中的 TransformerBlock.forward")


class TransformerLM(nn.Module):
    """输入 token ID 为 (B, N)，输出 logits 为 (B, N, vocab_size)。

    N 不超过 context_length；输出不包含 Softmax。
    """

    def __init__(self, vocab_size: int, context_length: int, d_model: int,
                 num_layers: int, num_heads: int, d_ff: int,
                 rope_theta: float = 10000.0):
        super().__init__()
        # TODO 7：根据讲义定义完整语言模型的组件。
        raise NotImplementedError("TODO 7：完成 transformer.py 中的 TransformerLM.__init__")

    def forward(self, token_ids: Tensor) -> Tensor:
        # TODO 7：组装完整语言模型的前向计算，返回 logits。
        raise NotImplementedError("TODO 7：完成 transformer.py 中的 TransformerLM.forward")
