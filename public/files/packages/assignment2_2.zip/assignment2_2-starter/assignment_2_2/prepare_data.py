"""数据预处理：用 HuggingFace tokenizers 在训练集上训练 BPE，再把两个划分编码成 token 文件。

在本作业目录运行 `python prepare_data.py`，在训练语料上训练BPE并且对训练语料分词并保存分词后的结果，输出的 .bin 是uint16 数组，用 np.memmap(path, dtype=np.uint16, mode="r") 读取。

"""

from itertools import batched
from pathlib import Path

import numpy as np
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

TRAIN_TEXT = Path("data/raw/TinyStoriesV2-GPT4-train.txt")
VAL_TEXT = Path("data/raw/TinyStoriesV2-GPT4-valid.txt")
OUT_DIR = Path("data/tokens")
VOCAB_SIZE = 10000
SPECIAL_TOKEN = "<|endoftext|>"


def read_chunks(path, chunk_chars=1 << 20):
    """按文档边界把文件切成约 chunk_chars 个字符的块，块拼起来就是原文。"""
    lines, size = [], 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            lines.append(line)
            size += len(line)
            if size >= chunk_chars and line.strip() == SPECIAL_TOKEN:
                yield "".join(lines)
                lines, size = [], 0
    if lines:
        yield "".join(lines)


def train_tokenizer(path, vocab_size):
    tokenizer = Tokenizer(models.BPE())
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tokenizer.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size, special_tokens=[SPECIAL_TOKEN],
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
    )
    # 先去掉特殊 token 再统计，避免把 "<|endoftext|>" 的碎片学进 merges。
    documents = (doc for chunk in read_chunks(path) for doc in chunk.split(SPECIAL_TOKEN))
    tokenizer.train_from_iterator(documents, trainer)
    return tokenizer


def encode_file(tokenizer, src, dst):
    count = 0
    with open(dst, "wb") as out:
        for chunks in batched(read_chunks(src), 32):
            for encoding in tokenizer.encode_batch(list(chunks)):
                np.array(encoding.ids, dtype=np.uint16).tofile(out)
                count += len(encoding.ids)
    return count


if __name__ == "__main__":
    print("Note: 在笔记本上通常要运行5~10min，请耐心等待或者挂在后台运行~")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    tokenizer = train_tokenizer(TRAIN_TEXT, VOCAB_SIZE)  # 只用训练集训练分词器
    tokenizer.save(str(OUT_DIR / "tokenizer.json"))
    print("词表大小：", tokenizer.get_vocab_size(), f"{SPECIAL_TOKEN} 的 ID：", tokenizer.token_to_id(SPECIAL_TOKEN))
    for src, name in ((TRAIN_TEXT, "train.bin"), (VAL_TEXT, "valid.bin")):
        print(f"{name}：{encode_file(tokenizer, src, OUT_DIR / name):,} 个 token")
