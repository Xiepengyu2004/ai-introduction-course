"""基础实验 2：实现旋转位置编码 RoPE。"""
import torch
from torch import nn, Tensor

class RotaryEmbedding(nn.Module):
    """输入和输出 (..., seq_len, d_head)，相邻两个特征构成一个旋转对。

    positions 是共享的一维整数索引 (seq_len,)，省略时使用 0 到 seq_len-1。
    theta 为旋转频率的底数。RoPE 无可训练参数。
    """

    def __init__(self, d_head: int, max_seq_len: int = 128, theta: float = 10000.0):
        super().__init__()
        if d_head <= 0 or d_head % 2 or max_seq_len <= 0 or theta <= 0:
            raise ValueError("d_head 必须为正偶数，max_seq_len 和 theta 必须为正")
        self.d_head = d_head
        self.max_seq_len = max_seq_len
        self.theta = theta

    def forward(self, x: Tensor, positions: Tensor | None = None) -> Tensor:
        if x.shape[-1] != self.d_head:
            raise ValueError("RoPE 输入最后一维必须等于 d_head")
        if positions is None:
            positions = torch.arange(x.shape[-2], device=x.device)
        if positions.ndim != 1 or positions.numel() != x.shape[-2]:
            raise ValueError("positions 必须是长度为 seq_len 的一维张量")
        if positions.dtype not in (torch.int32, torch.int64):
            raise ValueError("positions 必须是整数索引")
        if (positions < 0).any() or (positions >= self.max_seq_len).any():
            raise ValueError("位置索引超出 max_seq_len 范围")
        # TODO 3：计算旋转角度，对相邻特征对应用 RoPE，返回与 x 形状和 dtype 相同的张量。
        # tips: 可使用 torch.sin / torch.cos；
        raise NotImplementedError("TODO 3：完成 rope.py 中的 RotaryEmbedding.forward")