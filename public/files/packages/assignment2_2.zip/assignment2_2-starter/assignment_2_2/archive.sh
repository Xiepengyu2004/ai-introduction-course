#!/usr/bin/env bash
set -euo pipefail

if (($# > 1)); then
    printf 'Usage: %s [student_id]\n' "$0" >&2
    exit 2
fi

student_id=${1:-}
if [[ -n "$student_id" && ! "$student_id" =~ ^[[:alnum:]_-]+$ ]]; then
    printf 'Student ID may contain only letters, numbers, _ and -.\n' >&2
    exit 2
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo_root=$(dirname -- "$script_dir")
archive_name=${student_id:+${student_id}_}assignment2_2.zip
archive_path="$repo_root/$archive_name"

command -v zip >/dev/null || {
    printf 'The zip command is required.\n' >&2
    exit 1
}

tmp_archive=$(mktemp "$repo_root/.${archive_name}.tmp.XXXXXX")
trap 'rm -f -- "$tmp_archive"' EXIT
rm -f -- "$tmp_archive"

cd -- "$script_dir"
find . -mindepth 1 \
    \( -type d \( \
        -name .venv -o -name venv -o -name env -o -name ENV -o \
        -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache -o \
        -name .ruff_cache -o -name .ipynb_checkpoints -o -name .git -o \
        -name .tox -o -name .nox -o -name data -o -name checkpoints \
    \) -prune \) -o \
    \( -type f \( \
        -name '*.pyc' -o -name '*.pyo' -o -name '*.zip' -o \
        -name .DS_Store -o -name .env -o -name '*.pt' -o -name '*.pth' \
    \) -prune \) -o \
    -print | sed 's#^\./##' | zip -q "$tmp_archive" -@

mv -f -- "$tmp_archive" "$archive_path"
trap - EXIT
printf 'Created %s\n' "$archive_path"
