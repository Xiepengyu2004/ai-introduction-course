# 人工智能导论：Ass2_1

本实验完成基础组件、Transformer Block 与完整 Transformer LM 的组装。请阅读 [Notebook](TransformerBlock.ipynb)，完成内层 `assignment_2_1/` 包中的 TODO。

## 环境与测试

使用 Python 3.12 或 3.13。在解压得到的外层 `assignment_2_1/` 目录（包含本 README 和 Notebook）中运行：

```sh
python -m pip install -r requirements.txt
python -m notebook
```

Notebook 中包含分项测试。也可在同一目录运行 `python -m pytest -q`。

未完成 TODO 时，测试报告 `NotImplementedError`。请保留 `tests/_snapshots/` 与 `tests/fixtures/`，它们保存数值验收所需的参考输出和测试权重。

## 提交与后续实验

按 Notebook 要求提交代码、已运行的 Notebook 与报告。完成的内层模型包将在单独发布的 Ass2_2 中复用。AI 工具的使用要求见 [AGENTS.md](AGENTS.md)。
