from assignment_2_1 import RMSNorm, SwiGLU, CausalSelfAttention, TransformerBlock, TransformerLM
from assignment_2_1.attention import scaled_dot_product_attention
from assignment_2_1.rope import RotaryEmbedding


def run_rmsnorm(d_model, eps, weights, in_features):
    model = RMSNorm(d_model, eps).to(in_features)
    model.load_state_dict({'weight': weights})
    return model(in_features)


def run_swiglu(d_model, d_ff, w1_weight, w2_weight, w3_weight, in_features):
    model = SwiGLU(d_model, d_ff).to(in_features)
    model.load_state_dict({'w1.weight': w1_weight, 'w2.weight': w2_weight, 'w3.weight': w3_weight})
    return model(in_features)


def run_scaled_dot_product_attention(Q, K, V, mask=None):
    return scaled_dot_product_attention(Q, K, V, mask)


def run_rope(d_k, theta, max_seq_len, in_query_or_key, token_positions):
    model = RotaryEmbedding(d_k, max_seq_len, theta).to(in_query_or_key)
    return model(in_query_or_key, token_positions.reshape(-1))


def run_multihead_self_attention_with_rope(
    d_model, num_heads, max_seq_len, theta,
    q_proj_weight, k_proj_weight, v_proj_weight, o_proj_weight,
    in_features, token_positions=None,
):
    model = CausalSelfAttention(d_model, num_heads, max_seq_len, theta).to(in_features)
    model.load_state_dict({
        'q_proj.weight': q_proj_weight, 'k_proj.weight': k_proj_weight,
        'v_proj.weight': v_proj_weight, 'output_proj.weight': o_proj_weight,
    })
    positions = None if token_positions is None else token_positions.reshape(-1)
    return model(in_features, positions)


def run_transformer_block(d_model, num_heads, d_ff, max_seq_len, theta, weights, in_features):
    model = TransformerBlock(d_model, num_heads, d_ff, max_seq_len, theta).to(in_features)
    model.load_state_dict(weights)
    return model(in_features)


def run_transformer_lm(
    vocab_size, context_length, d_model, num_layers, num_heads, d_ff,
    rope_theta, weights, in_indices,
):
    model = TransformerLM(
        vocab_size=vocab_size, context_length=context_length, d_model=d_model,
        num_layers=num_layers, num_heads=num_heads, d_ff=d_ff, rope_theta=rope_theta,
    ).to(device=in_indices.device)
    model.load_state_dict(weights)
    return model(in_indices)
