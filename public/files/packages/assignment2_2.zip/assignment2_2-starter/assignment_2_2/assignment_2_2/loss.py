"""基础实验 1：交叉熵损失。"""

from torch import Tensor


def cross_entropy(inputs: Tensor, targets: Tensor) -> Tensor:
    """inputs 为 (..., vocab_size) 的 logits，targets 为 (...) 的整数目标。

    返回所有样本与位置的平均损失标量，保留用于反向传播的计算图。

    每个位置的损失是 -o[y] + log(sum_k exp(o[k]))，o 为该位置的 logits，y 为真实 token。
    先把前面的维度展平，再对所有位置取平均。
    exp 在 logits 很大时会溢出，先把每行减去它的最大值再算。
    """
    # TODO 2：按上面的步骤完成交叉熵。
    raise NotImplementedError("TODO 2：完成 loss.py 中的 cross_entropy")
