import torch
from tokenizers import Tokenizer

from assignment_2_1 import TransformerLM
from assignment_2_2 import train as cfg
from assignment_2_2.checkpoint import load_checkpoint
from assignment_2_2.opt import AdamW

TOKENIZER = "data/tokens/tokenizer.json"
PROMPT = "Once upon a time"
MAX_NEW_TOKENS = 256
TEMPERATURE = 0.8   # 越低越保守，越高越随机
SEED = 0


@torch.no_grad()
def generate(model, ids, eot_id):
    for _ in range(MAX_NEW_TOKENS):
        context = torch.tensor([ids[-cfg.CONTEXT_LENGTH:]], device=cfg.DEVICE)
        logits = model(context)[0, -1]
        probs = torch.softmax(logits / TEMPERATURE, dim=-1)
        next_id = torch.multinomial(probs, 1).item()
        if next_id == eot_id:
            break
        ids.append(next_id)
    return ids


if __name__ == "__main__":
    torch.manual_seed(SEED)
    tokenizer = Tokenizer.from_file(TOKENIZER)
    model = TransformerLM(
        vocab_size=cfg.VOCAB_SIZE, context_length=cfg.CONTEXT_LENGTH, d_model=cfg.D_MODEL,
        num_layers=cfg.NUM_LAYERS, num_heads=cfg.NUM_HEADS, d_ff=cfg.D_FF, rope_theta=cfg.ROPE_THETA,
    ).to(cfg.DEVICE)
    # load_checkpoint 需要一个优化器来接收状态；这里只用到模型。
    step = load_checkpoint(cfg.CHECKPOINT_PATH, model, AdamW(model.parameters()))
    model.eval()
    ids = generate(model, tokenizer.encode(PROMPT).ids, tokenizer.token_to_id("<|endoftext|>"))
    print(f"{cfg.CHECKPOINT_PATH}，第 {step} 步\n")
    print(tokenizer.decode(ids))
