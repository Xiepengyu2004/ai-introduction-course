"""基础实验 2：注意力。"""
from torch import nn, Tensor
from .rope import RotaryEmbedding


def scaled_dot_product_attention(
    q: Tensor, k: Tensor, v: Tensor, mask: Tensor | None = None,
) -> Tensor:
    """q: (..., L, Dk)，k: (..., S, Dk)，v: (..., S, Dv)。
    输出 (..., L, Dv)
    mask 为可广播到 (..., L, S) 的布尔张量：True 表示允许关注。
    每个 query 至少有一个可见 key；不测试空序列或全屏蔽行。
    """
    # TODO 4：完成缩放点积注意力
    # tips: 关注每一个tensor的shape ; 注意mask的语义.
    raise NotImplementedError("TODO 4：完成 attention.py 中的 scaled_dot_product_attention")


class CausalSelfAttention(nn.Module):
    """输入/输出 (B, N, d_model)，头内部维度为 d_model // num_heads。

    q/k 应用 RoPE，v 不旋转。positions 可省略，或为共享的 (N,) 索引。
    因果关系按序列顺序定义，包含当前位置；不是按 positions 数值构造。
    """

    def __init__(self, d_model: int, num_heads: int, max_seq_len: int = 128, theta: float = 10000.0):
        super().__init__()
        if num_heads <= 0 or d_model <= 0 or d_model % num_heads:
            raise ValueError("d_model 必须为正且能被正整数 num_heads 整除")
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_head = d_model // num_heads
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.output_proj = nn.Linear(d_model, d_model, bias=False)
        self.rope = RotaryEmbedding(self.d_head, max_seq_len, theta)

    def forward(self, x: Tensor, positions: Tensor | None = None) -> Tensor:
        # TODO 5：完成多头因果自注意力;
        # tips: 可以复用TODO3中的RoPE 和 TODO4中实现的SDPA
        # tips: 可以使用torch.tril/torch.triu来构造下三角/上三角矩阵
        raise NotImplementedError("TODO 5：完成 attention.py 中的 CausalSelfAttention.forward")
