# 测试来源

`test_model.py` 保留 CS336 原测试中本次需要的 9 个函数，函数正文、断言与容差不变。
`conftest.py`、`_snapshots/` 中的对应数据及 `fixtures/ts_tests/` 直接复制自原测试套件。
`common.py` 只保留测试数据目录定义。

教师提供的 `adapters.py` 将测试权重载入学生模块并调用 forward，学生无需修改。
本次采用含 RoPE 的多头注意力测试，并包含完整语言模型与截短输入测试；Linear、Embedding 不单独考核，可使用 PyTorch 提供的层。训练相关测试归入 Ass2_2。

在作业目录运行 `python -m pytest -q`。未完成的 TODO 会报告 NotImplementedError。
原 conftest 使用 Python 3.12 的类型参数语法，请使用 Python 3.12 或 3.13。
