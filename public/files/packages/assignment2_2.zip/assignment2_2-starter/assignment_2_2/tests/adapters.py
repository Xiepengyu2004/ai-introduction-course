"""教师测试适配器：调用学生自行编写的训练模块。"""


def run_get_batch(dataset, batch_size, context_length, device):
    from assignment_2_2.data_loading import get_batch

    return get_batch(dataset, batch_size, context_length, device)


def run_cross_entropy(inputs, targets):
    from assignment_2_2.loss import cross_entropy

    return cross_entropy(inputs, targets)


def run_gradient_clipping(parameters, max_l2_norm):
    from assignment_2_2.opt import gradient_clipping

    gradient_clipping(parameters, max_l2_norm)


def get_adamw_cls():
    from assignment_2_2.opt import AdamW

    return AdamW


def run_get_lr_cosine_schedule(
    it, max_learning_rate, min_learning_rate, warmup_iters, cosine_cycle_iters,
):
    from assignment_2_2.opt import get_lr_cosine_schedule

    return get_lr_cosine_schedule(
        it, max_learning_rate, min_learning_rate, warmup_iters, cosine_cycle_iters,
    )


def run_save_checkpoint(model, optimizer, iteration, out):
    from assignment_2_2.checkpoint import save_checkpoint

    save_checkpoint(model, optimizer, iteration, out)


def run_load_checkpoint(src, model, optimizer):
    from assignment_2_2.checkpoint import load_checkpoint

    return load_checkpoint(src, model, optimizer)
