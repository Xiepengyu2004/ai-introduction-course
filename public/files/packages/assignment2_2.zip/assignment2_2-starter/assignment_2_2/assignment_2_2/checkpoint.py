"""基础实验 3：保存与恢复训练状态。"""

from os import PathLike
from typing import BinaryIO

from torch import nn
from torch.optim import Optimizer


def save_checkpoint(
    model: nn.Module, optimizer: Optimizer, iteration: int,
    out: str | PathLike[str] | BinaryIO,
) -> None:
    """保存模型状态、优化器状态和已完成的迭代数。

    out 可以是文件路径或已打开的二进制文件对象。

    把 model.state_dict()、optimizer.state_dict() 和 iteration 放进一个字典，用 torch.save 保存。
    """
    # TODO 6：按上面的步骤完成 checkpoint 保存。
    raise NotImplementedError("TODO 6：完成 checkpoint.py 中的 save_checkpoint")


def load_checkpoint(
    src: str | PathLike[str] | BinaryIO, model: nn.Module, optimizer: Optimizer,
) -> int:
    """恢复模型与优化器状态，返回已完成的迭代数。

    src 可以是文件路径或已打开的二进制文件对象。

    用 torch.load 读出字典，分别对模型和优化器调用 load_state_dict，返回其中的 iteration。
    """
    # TODO 7：按上面的步骤完成 checkpoint 加载。
    raise NotImplementedError("TODO 7：完成 checkpoint.py 中的 load_checkpoint")
