"""基础实验 1："""
import torch
from torch import nn, Tensor


class RMSNorm(nn.Module):
    def __init__(self, d_model: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(d_model))

    def forward(self, x: Tensor) -> Tensor:
        # TODO 1：根据讲义完成 RMSNorm
        raise NotImplementedError("TODO 1：完成 layers.py 中的 RMSNorm.forward")


class SwiGLU(nn.Module):
    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.w1 = nn.Linear(d_model, d_ff, bias=False)
        self.w3 = nn.Linear(d_model, d_ff, bias=False)
        self.w2 = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        # TODO 2：门控前馈网络。
        # tips:可直接使用 torch.nn.functional.silu，或者自行引入之前实现好的激活函数；
        raise NotImplementedError("TODO 2：完成 layers.py 中的 SwiGLU.forward")
