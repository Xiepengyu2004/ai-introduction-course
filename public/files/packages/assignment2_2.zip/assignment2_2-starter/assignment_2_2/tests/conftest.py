from pathlib import Path

import numpy as np
import pytest


class NumpySnapshot:
    def __init__(self, test_name):
        self.path = Path(__file__).resolve().parent / "_snapshots" / f"{test_name}.npz"

    def assert_match(self, actual, rtol=1e-4, atol=1e-2):
        with np.load(self.path) as snapshot:
            np.testing.assert_allclose(
                actual.detach().cpu().numpy(), snapshot["array"], rtol=rtol, atol=atol,
            )


@pytest.fixture
def numpy_snapshot(request):
    return NumpySnapshot(request.node.name)
