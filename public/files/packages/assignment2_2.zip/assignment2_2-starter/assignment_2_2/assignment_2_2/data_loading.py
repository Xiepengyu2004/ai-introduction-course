"""基础实验 1：语言模型数据 batch。"""

import numpy as np
from torch import Tensor


def get_batch(
    dataset: np.ndarray, batch_size: int, context_length: int, device: str,
) -> tuple[Tensor, Tensor]:
    """从一维整数 token 数组中采样输入与下一 token 目标。

    dataset 也可以是 np.memmap。返回两个形状为 (B, N) 的整数张量，
    其中 B 为 batch_size、N 为 context_length，均位于指定 device。

    随机取起点 i，输入 x = dataset[i : i+N]，目标 y = dataset[i+1 : i+N+1]。
    注意 i 的范围：y 要读到 dataset[i+N]，所以最大的合法起点是 len(dataset) - N - 1。
    转成 torch.int64 再放到 device 上（dataset 可能是 uint16）。
    """
    # TODO 1：按上面的步骤完成 batch 采样。
    raise NotImplementedError("TODO 1：完成 data_loading.py 中的 get_batch")
