"""基础实验 3：验证、训练循环与训练入口。

在本作业目录运行 `python -m assignment_2_2.train`。训练配置写在下面的常量里，直接修改即可。
"""

import random
import time

import numpy as np
import torch
from torch import nn
from torch.optim import Optimizer

from assignment_2_1 import TransformerLM
from .checkpoint import load_checkpoint, save_checkpoint
from .data_loading import get_batch
from .loss import cross_entropy
from .opt import AdamW, get_lr_cosine_schedule, gradient_clipping

# ---------------------------------------------------------------------------
# 训练配置
#
# 默认是 CPU 短训练：4 × 500 × 256 = 512,000 个训练 token，用来检查程序能不能跑通。
# 正式训练时修改 BATCH_SIZE、TOTAL_STEPS、WARMUP_ITERS 和 COSINE_CYCLE_ITERS：
#   正式实验建议：32 × 5,000 × 256 = 40,960,000 token，例如 warmup 100，衰减到 5,000 步
#   更多资源时：  32 × 40,000 × 256 = 327,680,000 token，例如 warmup 400，衰减到 40,000 步
# 降低 batch 时同步增加步数，保持 token 预算不变。每个实验使用新的 CHECKPOINT_PATH。
# ---------------------------------------------------------------------------

# 数据：prepare_data.py 的输出，无文件头的 uint16 数组
TRAIN_DATA = "data/tokens/train.bin"
VAL_DATA = "data/tokens/valid.bin"
DTYPE = "uint16"

# 模型：讲义 §7.2 的配置
VOCAB_SIZE = 10000
CONTEXT_LENGTH = 256
D_MODEL = 512
NUM_LAYERS = 4
NUM_HEADS = 16
D_FF = 1344
ROPE_THETA = 10000.0

# 训练计划
BATCH_SIZE = 4
TOTAL_STEPS = 500           # 目标总迭代数；恢复训练时不变
MAX_LEARNING_RATE = 1e-3
MIN_LEARNING_RATE = 1e-4
WARMUP_ITERS = 50
COSINE_CYCLE_ITERS = 500    # 余弦衰减结束的迭代数

# AdamW 与梯度裁剪
BETAS = (0.9, 0.999)
EPS = 1e-8
WEIGHT_DECAY = 0.01
MAX_L2_NORM = 1.0

# 验证、checkpoint 与其他
VAL_EVERY = 100             # 每多少步验证一次
VAL_BATCHES = 10            # 每次验证评估多少个 batch
CHECKPOINT_EVERY = 100
CHECKPOINT_PATH = "checkpoints/cpu-short.pt" # 
RESUME_FROM = None          # 恢复训练时填 checkpoint 路径，例如 "checkpoints/ckpt-step500.pt"
DEVICE = "cpu"              # "cpu"、"cuda" 或 "mps"
SEED = 42


def evaluate(
    model: nn.Module, dataset: np.ndarray, batch_size: int,
    context_length: int, device: str, num_batches: int = 10,
) -> float:
    """在 dataset 上取 num_batches 个 batch，返回它们的平均 loss。

    验证结束后，模型参数、梯度和原来的训练/评估模式都保持不变：
        1. 记下 model.training，调用 model.eval()
        2. 在 torch.no_grad() 下循环 num_batches 次：get_batch → model → cross_entropy
        3. 把模型恢复成原来的模式，返回 loss 的平均值（Python float）
    """
    # TODO 8：按上面的步骤完成验证。
    raise NotImplementedError("TODO 8：完成 train.py 中的 evaluate")


def train(
    model: nn.Module, optimizer: Optimizer,
    train_dataset: np.ndarray, val_dataset: np.ndarray,
    start_iteration: int = 0,
) -> None:
    """按文件开头的配置训练到 TOTAL_STEPS，定期验证并保存 checkpoint。

    start_iteration 是已完成的迭代数，从头训练为 0，恢复训练时是 load_checkpoint 的返回值。

        for step in range(start_iteration, TOTAL_STEPS):
            lr = get_lr_cosine_schedule(step, ...)           # 写进 optimizer.param_groups
            x, y = get_batch(train_dataset, ...)
            loss = cross_entropy(model(x), y)
            optimizer.zero_grad(); loss.backward()
            gradient_clipping(model.parameters(), MAX_L2_NORM)
            optimizer.step()
            每 VAL_EVERY 步：evaluate 并打印 step、train/val loss、lr、累计训练 token、用时
            每 CHECKPOINT_EVERY 步：save_checkpoint(model, optimizer, step + 1, CHECKPOINT_PATH)
        训练结束时再保存一次

    调度用 step 计算，所以恢复后学习率会接着原来的位置，不会重新预热。
    保存的是已完成的步数 step + 1。日志用 print(..., flush=True)；保存前先创建 checkpoint 所在目录。
    """
    # TODO 9：按上面的伪代码完成训练循环。
    raise NotImplementedError("TODO 9：完成 train.py 中的 train")


def main() -> None:
    """准备数据、模型和优化器，必要时从 checkpoint 恢复，然后开始训练。"""
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    # memmap 只读打开，不会把大文件整个读进内存
    train_dataset = np.memmap(TRAIN_DATA, dtype=np.dtype(DTYPE), mode="r")
    val_dataset = np.memmap(VAL_DATA, dtype=np.dtype(DTYPE), mode="r")

    model = TransformerLM(
        vocab_size=VOCAB_SIZE, context_length=CONTEXT_LENGTH, d_model=D_MODEL,
        num_layers=NUM_LAYERS, num_heads=NUM_HEADS, d_ff=D_FF, rope_theta=ROPE_THETA,
    ).to(DEVICE)
    print(f"参数总数：{sum(p.numel() for p in model.parameters()):,}")
    optimizer = AdamW(
        model.parameters(), lr=MAX_LEARNING_RATE, betas=BETAS,
        eps=EPS, weight_decay=WEIGHT_DECAY,
    )

    start_iteration = 0
    if RESUME_FROM is not None:
        start_iteration = load_checkpoint(RESUME_FROM, model, optimizer)
        print(f"从 {RESUME_FROM} 恢复，已完成 {start_iteration} 步")

    train(model, optimizer, train_dataset, val_dataset, start_iteration)


if __name__ == "__main__":
    main()
