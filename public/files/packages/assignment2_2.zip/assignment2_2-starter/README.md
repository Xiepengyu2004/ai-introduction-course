# 人工智能导论：Ass2_2

本实验为选做，不计分。使用 Ass2_1 的模型完成训练、验证和文本生成，完整步骤见 [实验说明](assignment_2_2/README.md)。

把 Ass2_1 中完成的内层 `assignment_2_1/` 代码包复制到本发布包的 `assignment_2_2/assignment_2_1/`。后续安装依赖、准备数据和训练的命令，都在外层 `assignment_2_2/` 目录运行。
